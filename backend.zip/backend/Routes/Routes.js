const {Login,Register}=require("../controller/components-controller")

const routes=require("express").Router()



routes.post("/login",Login)
routes.post("/register",Register)




module.exports=routes;