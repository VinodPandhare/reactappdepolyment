const mongoose=require("mongoose")

const userRegister =mongoose.Schema({
  name: {
    type: String,
  },
  email: {
    type: String,
    unique: true,
    required: true,
  },
  password: {
    type: String,
    required: true,
  },
  phoneNumber: {
    type: String,
  },
});


const Registerdata2 = mongoose.model("Registerationdata", userRegister)
module.exports={Registerdata2}










