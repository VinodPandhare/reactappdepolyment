const mongoose=require("mongoose");
const cloudurl="mongodb+srv://ajayshelar5010:Ajay6070@cluster0.grys5hc.mongodb.net/ecommerce?retryWrites=true&w=majority&appName=Cluster0";


const connection=async ()=>{
    try{
      await mongoose.connect(cloudurl)
    }
    catch(err){
        console.log(err)
    }
  
}

module.exports=connection